import customtkinter as ctk
from settings import *
from time import strftime
from pygame import mixer
mixer.init()

stop_flag = None
parent_frame.place(anchor = "nw",relx = 0.02,rely = 0.0)

# MAJOR UPDATE : 
# the timer has been named as the 'timer' and all related functions 
# as well.
# the time (clock) tab has been switched with stopwatch

hour = secs = mins = 0
def reset_stop_watch():
    global hour, secs, mins
    hour = secs = mins = 0
    stop_watch_setup()

reset_stopwatch = button(114,70,text = " ⏹️ ", func = reset_stop_watch)
reset_stopwatch.master = parent_frame
reset_stopwatch.hover_color = "#7EA1B1"
reset_stopwatch.anchor = "center"
reset_stopwatch.relx = 0.38 ; reset_stopwatch.rely = 1-0.89

def stop_watch(): 
    global frame1, secs , mins, hour
    global stop_flag
    if stop_flag != None:
        frame2.place_forget()
        frame3.place_forget()
        secplus.place_forget()
        minplus.place_forget()
        hourplus.place_forget()
        reset.place_forget()
        start.place_forget()
        stop.place_forget()
        stop_watch_button.place_forget()
        app.after_cancel(stop_flag)
    
    stop_stopwatch.placerel()
    reset_stopwatch.placerel()

    secs += 1
    if secs >= 60:
        mins += 1
        secs = 0
    if mins >= 60:
        hour += 1
        mins = 0

    frame1.place(anchor = "center", relx = 0.5, rely = 0.5)
    time_label = ctk.CTkLabel(master=frame1,text = "",font=("Cascadia Mono NF Bold",40),text_color="#ffffff",justify = "center")
    time_label.place(anchor = "center",relx = 0.5,rely = 0.5)
    f = f"{hour:02} : {mins:02} : {secs:02}"
    time_label.configure(text = f)
    stop_flag = app.after(1000,stop_watch)

stop_watch_button = button(115,70,text = "  ▶️", func = stop_watch)
stop_watch_button.master = parent_frame
stop_watch_button.hover_color = "#7EA1B1"
stop_watch_button.anchor = "center"
stop_watch_button.relx = 0.38 ; stop_watch_button.rely = 0.89

def stop_watch_setup(): 
    global frame1, secs , mins, hour
    global stop_flag
    if stop_flag != None:
        frame2.place_forget()
        frame3.place_forget()
        secplus.place_forget()
        minplus.place_forget()
        hourplus.place_forget()
        reset.place_forget()
        start.place_forget()
        stop.place_forget()
        stop_stopwatch.place_forget()
        reset_stopwatch.place_forget()
        app.after_cancel(stop_flag)

    stop_watch_button.placerel()
    frame1.place(anchor = "center", relx = 0.5, rely = 0.5)
    time_label = ctk.CTkLabel(master=frame1,text = "",font=("Cascadia Mono NF Bold",40),text_color="#ffffff")
    time_label.place(anchor = "center",relx = 0.5,rely = 0.5)
    f = f"{hour:02} : {mins:02} : {secs:02}"
    time_label.configure(text = f)

stop_stopwatch = button(114,70,text = " ⏸️ ", func = stop_watch_setup)
stop_stopwatch.master = parent_frame
stop_stopwatch.hover_color = "#7EA1B1"
stop_stopwatch.anchor = "center"
stop_stopwatch.relx = 0.38 ; stop_stopwatch.rely = 0.89

sec = 0
minutes = 0
hours = 0
def sec_add():
    global sec, minutes, hours
    sec += 30
    if sec >= 60:
        minutes += 1
        sec = 0
    if minutes >= 60:
        hours += 1
        minutes = 0

def minutes_add():
    global sec, minutes, hours
    minutes += 1
    if minutes >= 60:
        hours += 1
        minutes = 0

def hours_add():
    global sec, minutes, hours
    hours += 1

def reset_time():
    global sec, minutes, hours
    sec = minutes = hours = 0
    start.place_forget()
    timer_setup()

time_up = mixer.music.load("timer.mp3")

def timer_setup():
    global stop_flag, frame2
    global sec, minutes, hours, timer_text
    if stop_flag != None:    
        frame1.place_forget()
        frame3.place_forget()
        stop.place_forget()
        pause.place_forget()
        stop_watch_button.place_forget()
        stop_stopwatch.place_forget()
        reset_stopwatch.place_forget()
        app.after_cancel(stop_flag)
    secplus.placerel()
    minplus.placerel()
    hourplus.placerel()
    reset.placerel()
    if sec > 0 or minutes > 0 or hours >0:
        start.placerel()
    mixer.music.pause()

    frame2.place(anchor = "center", relx = 0.5, rely = 0.5)
    time_label = ctk.CTkLabel(master=frame2,text =" ",font=("Cascadia Mono NF Bold",40),text_color="#ffffff",width = 300, height = 40, bg_color=Setting.frame_color)
    time_label.place(anchor = "center",relx = 0.5,rely = 0.5)

    timer_text = f"{hours:02} : {minutes:02} : {sec:02}"

    time_label.configure(text = timer_text)
    stop_flag = app.after(100,timer_setup)

def start_timer():
    global sec, minutes, hours
    global stop_flag, frame3, timer_text
    if stop_flag != None:
        reset.place_forget()
        secplus.place_forget()
        minplus.place_forget()
        hourplus.place_forget()
        start.place_forget()
        app.after_cancel(stop_flag)
    stop.placerel()
    pause.placerel()
    frame2.place(anchor = "center", relx = 0.5, rely = 0.5)
    time_label = ctk.CTkLabel(master=frame2,text =" ",font=("Cascadia Mono NF Bold",40),text_color="#ffffff",width = 300, height = 40, bg_color=Setting.frame_color)
    time_label.place(anchor = "center",relx = 0.52,rely = 0.5)
    

    if sec <= 0 and minutes <= 0 and hours <= 0:
        timer_text = f"00 : 00 : 00"
        hours = sec = minutes = 0
        mixer.music.play(-1)

    if sec>0:
        sec -=1
    else:
        if minutes > 0:
            sec = 59
            minutes -=1
        if minutes <= 0 and hours>0:
                hours -=1
                minutes = 59
                sec = 59
        elif hours > 0 and minutes < 0 and sec<0:
            hours -= 1
            minutes = 59
            sec = 59

    
    timer_text = f"{hours:02} : {minutes:02} : {sec:02} "

    time_label.configure(text = timer_text)
    stop_flag = app.after(1000,start_timer)
               

start = button(113,70,text = "  ▶️", func = start_timer)
start.master = parent_frame
start.hover_color = "#7EA1B1"
start.anchor = "center"
start.relx = 0.5 ; start.rely = 0.89

secplus = button(40,50,text = "+30 S",func= sec_add)
secplus.master = parent_frame
secplus.hover_color = "#7EA1B1"
secplus.relx = 0.58 ; secplus.rely = 0.12

minplus = button(50,50,text = "+1 M ", func = minutes_add)
minplus.master = parent_frame
minplus.hover_color = "#7EA1B1"
minplus.relx = 0.38 ; minplus.rely = 0.12

hourplus = button(50,50,text = "+1 H ", func = hours_add)
hourplus.master = parent_frame
hourplus.hover_color = "#7EA1B1"
hourplus.relx = 0.18 ; hourplus.rely = 0.12

reset = button(110,70,text = "  🔄️", func = reset_time)
reset.master = parent_frame
reset.hover_color = "#7EA1B1"
reset.relx = 0.26 ; reset.rely = 0.89

stop = button(115,70,text = "⏹️", func = reset_time)
stop.master = parent_frame
stop.hover_color = "#7EA1B1"
stop.relx = 0.26 ; stop.rely = 0.89

pause = button(115,70,text = "⏸", func = timer_setup)
pause.master = parent_frame
pause.hover_color = "#7EA1B1"
pause.anchor = "center"
pause.relx = 0.5 ; pause.rely = 0.89