import customtkinter as ctk
app = ctk.CTk("#121519")

class Setting:
    # settings related to window and gui
    SCREEN_WIDTH = app.winfo_screenwidth()
    SCREEN_HEIGHT = app.winfo_screenheight()
    color_scheme = "#878598"
    frame_color = "#3A3840"
    x = 550
    y = 360
    app.geometry(f"{x}x{y}+{SCREEN_WIDTH-x}+{SCREEN_HEIGHT-y*1.5}")
    app.resizable(0,0)
    app.title("Timer")
    app._set_appearance_mode("dark")
#widget frame
parent_frame = ctk.CTkFrame(app,width = 400,height = 360,corner_radius=0,fg_color="#121519")
frame1 = ctk.CTkFrame(parent_frame,width=300,height = 200,corner_radius=80,fg_color=Setting.frame_color)
frame2 = ctk.CTkFrame(parent_frame,width=300,height = 200,corner_radius=80,fg_color=Setting.frame_color)
frame3 = ctk.CTkFrame(parent_frame,width=300,height = 200,corner_radius=80,fg_color=Setting.frame_color)
class button:
    def __init__(self, sizex : int, sizey : int, func, text:str = "Click"):
        self.master = app
        self.relx = 0 ; self.rely = 0
        self.posx = 0 ; self.posy = 0
        self.anchor = "center"
        self.fg_color = "#2F2D38" ; self.hover_color = Setting.color_scheme;
        self.bg_color = "#121519"

        self.button = ctk.CTkButton(app,width = sizex,height = sizey,corner_radius=15,border_spacing=3,fg_color = self.fg_color,
                        text = text,text_color="#FFFFFF",command=func,
                        font=("Cascadia Code SemiBold",24),
                        hover_color=self.hover_color, bg_color= self.bg_color)
        
    def placeit(self):
        self.button.place(anchor = self.anchor,x = self.posx, y = self.posy)
    def placerel(self):
        self.button.place(anchor = self.anchor , relx = self.relx, rely = self.rely)
    def destruct(self):
        self.button.destroy()
    def place_forget(self):
        self.button.place_forget()